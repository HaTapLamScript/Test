// [MAMBO PROJECT] Cloudflare Worker Backend
import { DurableObject } from "cloudflare:workers";

const jsonResponse = (body, status, corsHeaders) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, "Content-Type": "application/json" }
});

const base64UrlEncode = (value) => {
  const bytes = value instanceof Uint8Array ? value : new TextEncoder().encode(value);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
};

const base64UrlDecode = (value) => {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(normalized + "=".repeat((4 - normalized.length % 4) % 4));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
};

const signToken = async (payload, secret) => {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
  return `${payload}.${base64UrlEncode(new Uint8Array(signature))}`;
};

const verifyToken = async (token, secret) => {
  if (!secret || typeof token !== "string") return false;
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  try {
    const payload = JSON.parse(new TextDecoder().decode(base64UrlDecode(parts[0])));
    if (!payload.exp || payload.exp < Date.now()) return false;
    const expected = await signToken(parts[0], secret);
    const expectedBytes = new TextEncoder().encode(expected.split(".")[1]);
    const actualBytes = new TextEncoder().encode(parts[1]);
    if (expectedBytes.length !== actualBytes.length) return false;
    let difference = 0;
    for (let index = 0; index < expectedBytes.length; index += 1) difference |= expectedBytes[index] ^ actualBytes[index];
    return difference === 0;
  } catch {
    return false;
  }
};

const isAdmin = async (request, env) => {
  const authHeader = request.headers.get("Authorization") || "";
  return verifyToken(authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "", env.ADMIN_SECRET_KEY);
};

const issueAdminToken = async (secret) => {
  const payload = base64UrlEncode(JSON.stringify({ exp: Date.now() + 60 * 60 * 1000, nonce: crypto.randomUUID() }));
  return signToken(payload, secret);
};

const isHexColor = (value) => typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value);
const validFonts = new Set(["normal", "bold", "italic", "mono", "bold-glow"]);
const normalizedTitle = (titleText, color, font) => ({
  text: typeof titleText === "string" ? titleText.trim().slice(0, 50) : "",
  color: isHexColor(color) ? color : "#10b981",
  font: validFonts.has(font) ? font : "normal"
});

const roomRequest = async (env, path, method, body) => {
  const id = env.MAMBO_CHAT.idFromName("global");
  const stub = env.MAMBO_CHAT.get(id);
  return stub.fetch(new Request(`https://mambo-chat.internal${path}`, {
    method,
    headers: { "Content-Type": "application/json" },
    body: method === "GET" ? undefined : JSON.stringify(body)
  }));
};

const withCors = async (response, corsHeaders) => {
  const headers = new Headers(response.headers);
  for (const [key, value] of Object.entries(corsHeaders)) headers.set(key, value);
  return new Response(response.body, { status: response.status, headers });
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Signature"
    };

    if (request.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

    try {
      if (path === "/api/admin/login" && request.method === "POST") {
        const { password } = await request.json();
        if (!env.ADMIN_SECRET_KEY || typeof password !== "string" || password !== env.ADMIN_SECRET_KEY) return jsonResponse({ error: "Invalid credentials" }, 401, corsHeaders);
        return jsonResponse({ success: true, token: await issueAdminToken(env.ADMIN_SECRET_KEY), expiresIn: 3600 }, 200, corsHeaders);
      }

      if (path === "/api/chat/send" && request.method === "POST") {
        const body = await request.json();
        const response = await roomRequest(env, "/message", "POST", body);
        return withCors(response, corsHeaders);
      }

      if (path === "/api/chat/get" && request.method === "GET") {
        const response = await roomRequest(env, "/messages", "GET");
        return withCors(response, corsHeaders);
      }

      if (path === "/api/chat/private/send" && request.method === "POST") {
        const response = await roomRequest(env, "/private-message", "POST", await request.json());
        return withCors(response, corsHeaders);
      }

      if (path === "/api/chat/private/get" && request.method === "GET") {
        const userId = new URL(request.url).searchParams.get("userId") || "";
        const response = await roomRequest(env, `/private-messages?userId=${encodeURIComponent(userId)}`, "GET");
        return withCors(response, corsHeaders);
      }

      if (path === "/api/chat/players" && request.method === "GET") {
        const response = await roomRequest(env, "/players", "GET");
        return withCors(response, corsHeaders);
      }

      if (path === "/api/chat/presence" && request.method === "POST") {
        const body = await request.json();
        const response = await roomRequest(env, "/presence", "POST", body);
        return withCors(response, corsHeaders);
      }

      if (path.startsWith("/api/admin/") && path !== "/api/admin/login") {
        if (!(await isAdmin(request, env))) return jsonResponse({ error: "Unauthorized" }, 401, corsHeaders);
      }

      if (path === "/api/admin/broadcast" && request.method === "POST") {
        const body = await request.json();
        const response = await roomRequest(env, "/broadcast", "POST", body);
        return withCors(response, corsHeaders);
      }

      if (path === "/api/admin/real-info" && request.method === "GET") {
        const response = await roomRequest(env, "/messages?view=admin", "GET");
        return withCors(response, corsHeaders);
      }

      if (path === "/api/admin/clear" && request.method === "POST") {
        const response = await roomRequest(env, "/clear", "POST", {});
        return withCors(response, corsHeaders);
      }

      if (path === "/api/admin/ban" && request.method === "POST") {
        const body = await request.json();
        const response = await roomRequest(env, "/ban", "POST", body);
        return withCors(response, corsHeaders);
      }

      if (path === "/api/admin/bans" && request.method === "GET") {
        const response = await roomRequest(env, "/bans", "GET");
        return withCors(response, corsHeaders);
      }

      if (path === "/api/admin/presence" && request.method === "GET") {
        const response = await roomRequest(env, "/presence", "GET");
        return withCors(response, corsHeaders);
      }

      if (path === "/api/admin/unban" && request.method === "POST") {
        const body = await request.json();
        const response = await roomRequest(env, "/unban", "POST", body);
        return withCors(response, corsHeaders);
      }

      if (path === "/api/admin/title" && request.method === "POST") {
        const body = await request.json();
        const response = await roomRequest(env, "/title", "POST", body);
        return withCors(response, corsHeaders);
      }

      if (path === "/" && env.ASSETS) return env.ASSETS.fetch(new Request(new URL("/admin.html", request.url), request));
      if (env.ASSETS) return env.ASSETS.fetch(request);
      return new Response("Mambo Global Chat Backend Active", { headers: corsHeaders });
    } catch (error) {
      return jsonResponse({ error: error instanceof Error ? error.message : "Internal Server Error" }, 500, corsHeaders);
    }
  }
};

export class MamboGlobalChat extends DurableObject {
  async readState() {
    const messages = await this.ctx.storage.get("messages");
    const bannedUsers = await this.ctx.storage.get("bannedUsers");
    const customTitles = await this.ctx.storage.get("customTitles");
    const anonTags = await this.ctx.storage.get("anonTags");
    const nextAnonTag = await this.ctx.storage.get("nextAnonTag");
    const presence = await this.ctx.storage.get("presence");
    const privateMessages = await this.ctx.storage.get("privateMessages");
    return { messages: messages || [], bannedUsers: bannedUsers || {}, customTitles: customTitles || {}, anonTags: anonTags || {}, nextAnonTag: Number.isInteger(nextAnonTag) ? nextAnonTag : 0, presence: presence || {}, privateMessages: privateMessages || [] };
  }

  async fetch(request) {
    const path = new URL(request.url).pathname;
    const state = await this.readState();

    if (path === "/messages" && request.method === "GET") {
      const adminView = new URL(request.url).searchParams.get("view") === "admin";
      const messages = adminView ? state.messages : state.messages.map((message) => {
        const { realUsername, displayName, adminJobId, adminGameName, adminPlaceId, ...publicMessage } = message;
        return publicMessage;
      });
      return Response.json({ success: true, messages });
    }

    if (path === "/message" && request.method === "POST") {
      const body = await request.json();
      const { userId, username, realUsername, displayName, text, jobId, adminJobId, gameName, adminGameName, isAnon } = body;
      if (!userId || typeof userId !== "string" || !username || typeof username !== "string") return Response.json({ error: "Invalid user data" }, { status: 400 });
      if (state.bannedUsers[userId]) {
        const banEntry = typeof state.bannedUsers[userId] === "object" ? state.bannedUsers[userId] : { expires: state.bannedUsers[userId], reason: "" };
        if (Number(banEntry.expires) > Date.now()) return Response.json({ error: "Banned", expires: Number(banEntry.expires), reason: banEntry.reason || "" }, { status: 403 });
        delete state.bannedUsers[userId];
      }
      if (typeof text !== "string" || text.trim().length === 0 || text.length > 100) return Response.json({ error: "Invalid text length (Max 100 chars)" }, { status: 400 });
      const userTitle = state.customTitles[userId] || normalizedTitle("", "#10b981", "normal");
      if (isAnon && !state.anonTags[userId]) {
        state.nextAnonTag = state.nextAnonTag >= 999 ? 1 : state.nextAnonTag + 1;
        state.anonTags[userId] = `Mambo-${String(state.nextAnonTag).padStart(3, "0")}`;
        await this.ctx.storage.put("anonTags", state.anonTags);
        await this.ctx.storage.put("nextAnonTag", state.nextAnonTag);
      }
      const messageData = {
        id: `${Date.now()}${Math.random().toString(36).substring(2, 7)}`,
        userId,
        username: isAnon ? "Anonymous" : username,
        realUsername: typeof realUsername === "string" && realUsername.trim() ? realUsername.trim().slice(0, 30) : username,
        displayName: typeof displayName === "string" && displayName.trim() ? displayName.trim().slice(0, 30) : username,
        adminJobId: typeof adminJobId === "string" ? adminJobId : "",
        placeId: typeof body.placeId === "string" ? body.placeId : String(body.placeId || ""),
        adminPlaceId: typeof body.adminPlaceId === "string" ? body.adminPlaceId : String(body.adminPlaceId || body.placeId || ""),
        adminGameName: typeof adminGameName === "string" && adminGameName.length > 0 ? adminGameName : "Unknown Game",
        isAnon: Boolean(isAnon),
        text,
        jobId: typeof jobId === "string" ? jobId : "",
        gameName: typeof gameName === "string" && gameName.length > 0 ? gameName : "Unknown Game",
        title: isAnon ? state.anonTags[userId] : userTitle.text,
        titleColor: isAnon ? "#34d399" : userTitle.color,
        titleFont: userTitle.font,
        isAdminMsg: false,
        timestamp: Date.now()
      };
      state.messages.push(messageData);
      if (state.messages.length > 50) state.messages.shift();
      await this.ctx.storage.put("messages", state.messages);
      if (state.bannedUsers[userId] === undefined) await this.ctx.storage.put("bannedUsers", state.bannedUsers);
      state.presence[userId] = { timestamp: Date.now(), userId, username: isAnon ? "Anonymous" : username, displayName: typeof displayName === "string" ? displayName.slice(0, 30) : username, jobId: typeof jobId === "string" ? jobId : "", placeId: typeof body.placeId === "string" ? body.placeId : String(body.placeId || ""), gameName: typeof gameName === "string" ? gameName.split("\x1F")[0].slice(0, 80) : "Unknown Game", allowPrivate: body.allowPrivate !== false, allowJoin: body.allowJoin !== false };
      await this.ctx.storage.put("presence", state.presence);
      return Response.json({ success: true, data: messageData });
    }

    if (path === "/private-message" && request.method === "POST") {
      const body = await request.json();
      const { userId, targetUserId, username, realUsername, displayName, text, placeId, jobId } = body;
      if (!userId || !targetUserId || userId === targetUserId || typeof userId !== "string" || typeof targetUserId !== "string") return Response.json({ error: "Invalid private chat users" }, { status: 400 });
      const banEntry = state.bannedUsers[userId] && (typeof state.bannedUsers[userId] === "object" ? state.bannedUsers[userId] : { expires: state.bannedUsers[userId], reason: "" });
      if (banEntry && Number(banEntry.expires) > Date.now()) return Response.json({ error: "Banned", expires: Number(banEntry.expires), reason: banEntry.reason || "" }, { status: 403 });
      if (typeof text !== "string" || !text.trim() || text.length > 100) return Response.json({ error: "Invalid text length (Max 100 chars)" }, { status: 400 });
      const privateMessage = { id: `PRIVATE-${Date.now()}${Math.random().toString(36).slice(2, 7)}`, userId, targetUserId, username: typeof username === "string" ? username.slice(0, 30) : "Unknown", realUsername: typeof realUsername === "string" ? realUsername.slice(0, 30) : "Unknown", displayName: typeof displayName === "string" ? displayName.slice(0, 30) : "Unknown", text: text.trim(), placeId: typeof placeId === "string" ? placeId : String(placeId || ""), jobId: typeof jobId === "string" ? jobId : "", timestamp: Date.now(), isPrivate: true };
      state.privateMessages.push(privateMessage);
      if (state.privateMessages.length > 200) state.privateMessages.splice(0, state.privateMessages.length - 200);
      await this.ctx.storage.put("privateMessages", state.privateMessages);
      return Response.json({ success: true, data: privateMessage });
    }

    if (path === "/private-messages" && request.method === "GET") {
      const userId = new URL(request.url).searchParams.get("userId") || "";
      if (!userId) return Response.json({ error: "Missing userId" }, { status: 400 });
      const messages = state.privateMessages.filter((message) => message.userId === userId || message.targetUserId === userId);
      return Response.json({ success: true, messages });
    }

    if (path === "/clear" && request.method === "POST") {
      await this.ctx.storage.put("messages", []);
      return Response.json({ success: true, cleared: true });
    }

    if (path === "/presence" && request.method === "POST") {
      const body = await request.json();
      const { userId } = body;
      if (!userId || typeof userId !== "string") return Response.json({ error: "Invalid presence data" }, { status: 400 });
      state.presence[userId] = { timestamp: Date.now(), userId, username: typeof body.username === "string" ? body.username.slice(0, 30) : "Unknown", displayName: typeof body.displayName === "string" ? body.displayName.slice(0, 30) : "Unknown", jobId: typeof body.jobId === "string" ? body.jobId : "", placeId: typeof body.placeId === "string" ? body.placeId : "", gameName: typeof body.gameName === "string" ? body.gameName.slice(0, 80) : "Unknown Game", allowPrivate: body.allowPrivate !== false, allowJoin: body.allowJoin !== false };
      await this.ctx.storage.put("presence", state.presence);
      return Response.json({ success: true });
    }

    if (path === "/presence" && request.method === "GET") {
      const cutoff = Date.now() - 120000;
      const active = Object.values(state.presence).filter((entry) => Number(typeof entry === "object" ? entry.timestamp : entry) >= cutoff).length;
      return Response.json({ success: true, count: active });
    }

    if (path === "/players" && request.method === "GET") {
      const cutoff = Date.now() - 120000;
      const players = Object.values(state.presence).map((entry) => typeof entry === "object" ? entry : { userId: "", timestamp: Number(entry) }).filter((entry) => entry.userId && Number(entry.timestamp) >= cutoff && entry.allowPrivate !== false);
      return Response.json({ success: true, players });
    }


    if (path === "/bans" && request.method === "GET") {
      const now = Date.now();
      const bans = Object.entries(state.bannedUsers).map(([userId, entry]) => {
        const normalized = typeof entry === "object" ? entry : { expires: entry, reason: "No reason provided" };
        return { userId, expires: Number(normalized.expires), reason: normalized.reason || "No reason provided" };
      }).filter((entry) => entry.expires > now);
      return Response.json({ success: true, bans });
    }

    if (path === "/broadcast" && request.method === "POST") {
      const { text, adminName } = await request.json();
      if (typeof text !== "string" || text.trim().length === 0 || text.length > 150) return Response.json({ error: "Invalid text length (Max 150 chars)" }, { status: 400 });
      const messageData = { id: `ADMIN-${Date.now()}`, userId: "OWNER-ROOT", username: typeof adminName === "string" && adminName.trim() ? adminName.trim().slice(0, 30) : "MAMBO OWNER", realUsername: "SYSTEM OWNER", text, jobId: "GLOBAL BROADCAST", gameName: "SYSTEM ANNOUNCEMENT", title: "OWNER", titleColor: "#00ff66", titleFont: "bold-glow", isAdminMsg: true, timestamp: Date.now() };
      state.messages.push(messageData);
      if (state.messages.length > 50) state.messages.shift();
      await this.ctx.storage.put("messages", state.messages);
      return Response.json({ success: true, data: messageData });
    }

    if (path === "/ban" && request.method === "POST") {
      const { targetUserId, durationMinutes, reason } = await request.json();
      if (!targetUserId || typeof targetUserId !== "string" || !Number.isFinite(durationMinutes) || durationMinutes < 0) return Response.json({ error: "Invalid ban data" }, { status: 400 });
      const expires = durationMinutes === 0 ? 8640000000000 : Date.now() + durationMinutes * 60 * 1000;
      const cleanReason = typeof reason === "string" ? reason.trim().slice(0, 200) : "";
      state.bannedUsers[targetUserId] = { expires, reason: cleanReason || "No reason provided" };
      await this.ctx.storage.put("bannedUsers", state.bannedUsers);
      return Response.json({ success: true, banned: targetUserId, expires, reason: cleanReason || "No reason provided" });
    }

    if (path === "/unban" && request.method === "POST") {
      const { targetUserId } = await request.json();
      if (!targetUserId || typeof targetUserId !== "string") return Response.json({ error: "Invalid user data" }, { status: 400 });
      delete state.bannedUsers[targetUserId];
      await this.ctx.storage.put("bannedUsers", state.bannedUsers);
      return Response.json({ success: true, unbanned: targetUserId });
    }

    if (path === "/title" && request.method === "POST") {
      const { targetUserId, titleText, color, font } = await request.json();
      if (!targetUserId || typeof targetUserId !== "string" || typeof titleText !== "string" || titleText.trim().length === 0 || titleText.length > 50) return Response.json({ error: "Invalid title data" }, { status: 400 });
      state.customTitles[targetUserId] = normalizedTitle(titleText, color, font);
      await this.ctx.storage.put("customTitles", state.customTitles);
      return Response.json({ success: true, target: targetUserId, title: state.customTitles[targetUserId] });
    }

    return Response.json({ error: "Not found" }, { status: 404 });
  }
}
