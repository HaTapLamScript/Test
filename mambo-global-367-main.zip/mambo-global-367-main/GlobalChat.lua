-- [MAMBO PROJECT] Global Chat Client

local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local CoreGui = game:GetService("CoreGui")
local HttpService = game:GetService("HttpService")
local MarketplaceService = game:GetService("MarketplaceService")
local TeleportService = game:GetService("TeleportService")

local LP = Players.LocalPlayer
local Camera = workspace.CurrentCamera

for _, g in pairs(CoreGui:GetChildren()) do
    if g.Name == "MamboGlobalChat" or g.Name == "MamboGlobalChat_Setup" then g:Destroy() end
end

local isVN = false
pcall(function()
    local loc = LP.LocaleId or game:GetService("LocalizationService").RobloxLocaleId or ""
    if string.match(string.lower(loc), "^vi") then isVN = true end
end)

local T = {
    APP_SETUP = isVN and "MAMBO GLOBAL CHAT // CÀI ĐẶT" or "MAMBO GLOBAL CHAT // SETUP",
    APP_MAIN = "MAMBO GLOBAL CHAT",
    ANON = isVN and "Chế độ Ẩn danh" or "Anonymous Mode",
    ALLOW_JOIN = isVN and "Cho phép Join Server" or "Allow Join",
    ALLOW_PRIVATE = isVN and "Nhận Private Chat" or "Allow Private Chat",
    SHOW_STATUS = isVN and "Hiển thị Trạng thái Game" or "Show Game Status",
    OVERHEAD = isVN and "Bong bóng Chat trên đầu" or "Overhead Chat Bubble",
    APPLY = isVN and "[ ÁP DỤNG ]" or "[ APPLY ]",
    SEND = isVN and "GỬI" or "SEND",
    INPUT_PH = isVN and "Nhập tin nhắn..." or "Type a message...",
    CONNECTING = isVN and "Đang kết nối..." or "Connecting...",
    ONLINE = isVN and "● Trực tuyến" or "● Online",
    OFFLINE = isVN and "✕ Mất kết nối" or "✕ Disconnected",
    SENDING = isVN and "Đang gửi..." or "Sending...",
    SENT = isVN and "● Đã gửi" or "● Sent",
    SEND_FAILED = isVN and "✕ Gửi thất bại" or "✕ Send failed",
    BANNED = isVN and "⚠ Bạn đã bị ban, còn " or "⚠ You are banned for ",
    CONN_FAILED = isVN and "✕ Không thể kết nối" or "✕ Connection failed",
    NO_MSG = isVN and "Chưa có tin nhắn nào..." or "No messages yet...",
    VIEW_MORE = isVN and "(xem thêm)" or "(more)",
    VIEW_LESS = isVN and "(thu gọn)" or "(less)",
    MUTE_LIST = isVN and "DS CHẶN" or "MUTE LIST",
    SETTINGS = isVN and "CÀI ĐẶT" or "SETTINGS",
    MUTE_TITLE = isVN and "DANH SÁCH CHẶN" or "MUTED USERS",
    NO_MUTE = isVN and "Chưa chặn ai" or "No one muted",
    UNMUTE = isVN and "Bỏ chặn" or "Unmute",
    GUIDE_TITLE = isVN and "HƯỚNG DẪN" or "GUIDE",
    GUIDE_TEXT = isVN and "MAMBO GLOBAL CHAT\n\n1. Nhập tin nhắn (tối đa 100 ký tự).\n2. Nhấn GỬI hoặc Enter để gửi.\n3. Chờ 30 giây giữa các lần gửi.\n4. Click tên người dùng để xem hồ sơ (Join / Chat riêng / Chặn).\n5. DS CHẶN để quản lý danh sách.\n6. CÀI ĐẶT để chỉnh tùy chọn.\n7. Tin nhắn từ người chơi cùng server có thể hiện bong bóng trên đầu." or "MAMBO GLOBAL CHAT\n\n1. Type message (max 100 chars).\n2. Hit SEND or Enter to submit.\n3. 30s cooldown between sends.\n4. Click username to view profile (Join / Private / Mute).\n5. MUTE LIST to manage blocked users.\n6. SETTINGS to adjust options.\n7. Messages from same-server players may show overhead bubbles.",
    OK = "OK",
    JOIN_SERVER = isVN and "[ Vào Server ]" or "[ Join Server ]",
    PRIVATE_CHAT = isVN and "[ Chat Riêng ]" or "[ Private Chat ]",
    GLOBAL_TAB = isVN and "GLOBAL" or "GLOBAL CHAT",
    PRIVATE_TAB = isVN and "RIÊNG" or "PRIVATE CHAT",
    SELECT_PLAYER = isVN and "Chọn người chơi" or "Select player",
    NO_PLAYERS = isVN and "Không có người chơi online" or "No players online",
    PRIVATE_EMPTY = isVN and "Chọn một người chơi để bắt đầu chat riêng" or "Select a player to start a private chat",
    MUTE = isVN and "[ Chặn ]" or "[ Mute ]",
    UNMUTE_BTN = isVN and "[ Bỏ Chặn ]" or "[ Unmute ]",
    ONLINE_GAME = isVN and "● Trực tuyến - " or "● Online - ",
    OFFLINE_TIME = isVN and "○ Ngoại tuyến - " or "○ Offline - ",
    UNKNOWN = isVN and "Không rõ" or "Unknown",
    HIDDEN = isVN and "Ẩn" or "Hidden",
    USER_LOWER = isVN and "người dùng" or "user"
}

local API = "https://mambo-global-367.hadieu54546565.workers.dev"
local LOGO_URL = "https://raw.githubusercontent.com/HaTapLamScript/MAMBO-PROJECT/main/Script/MAMBO_logo.png"
local LOGO_FILE = "[MAMBO PROJECT]/MAMBO_logo.png"
local CONFIG_FILE = "[MAMBO PROJECT]/GlobalChat/config.json"
local MUTE_FILE = "[MAMBO PROJECT]/GlobalChat/mute.json"
local MAX_LEN = 100
local COOLDOWN = 30
local POLL_INTERVAL = 3
local SEP = "\x1F"
local STATUS_WINDOW = 120

local function s(offset)
    local scale = math.min(Camera.ViewportSize.X / 1920, Camera.ViewportSize.Y / 1080) * (2.4 * 1.2 * 0.9 * 0.85)
    return math.floor(offset * scale + 0.5)
end

local C = {
    bg = Color3.fromRGB(10, 10, 10),
    glass = Color3.fromRGB(20, 20, 20),
    text = Color3.fromRGB(255, 255, 255),
    dim = Color3.fromRGB(150, 150, 150),
    accent = Color3.fromRGB(0, 255, 0),
    accentDark = Color3.fromRGB(0, 150, 0),
    danger = Color3.fromRGB(255, 0, 0),
    warning = Color3.fromRGB(255, 255, 0),
    purple = Color3.fromRGB(196, 181, 253),
    font = Enum.Font.Code
}

local Connections = {}
local PollingActive = true
local CleanedUp = false
local BillboardGuis = {}
local SeenIds = {}
local UserCache = {}
local ExpandedMsgs = {}

local Settings = {anon = false, allowJoin = true, allowPrivate = true, showGameStatus = true, overheadBubble = true}
local MutedUsers = {}
local MiniPos = nil

local MainGui, StartupGui, StatusLabel, SendBtn, InputBox, ChatScroll, MainPanel
local GlobalTabBtn, PrivateTabBtn, PrivateTargetBtn
local LastSendTime = 0
local LastMessageId = nil
local GlobalMessages = {}
local PrivateMessages = {}
local PrivateTarget = nil
local CurrentTab = "global"
local IsConnected = false

local buildMain, showProfile, cleanup, showMuteList, buildStartup, showPlayerPicker

local function addCorners(g, r) local c = Instance.new("UICorner"); c.CornerRadius = UDim.new(0, r or s(6)); c.Parent = g; return c end
local function addStroke(g, color, thick) local st = Instance.new("UIStroke"); st.Color = color; st.Thickness = thick or s(1); st.ApplyStrokeMode = Enum.ApplyStrokeMode.Border; st.Parent = g; return st end
local function escape(text) text = tostring(text or ""); text = text:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"):gsub('"', "&quot;"); return text end
local function track(conn) table.insert(Connections, conn); return conn end

pcall(function()
    if not isfolder("[MAMBO PROJECT]") then makefolder("[MAMBO PROJECT]") end
    if not isfolder("[MAMBO PROJECT]/GlobalChat") then makefolder("[MAMBO PROJECT]/GlobalChat") end
end)

local function ensureLogo()
    if not isfile(LOGO_FILE) then
        local req = request or http_request or (syn and syn.request) or (fluxus and fluxus.request)
        if req then pcall(function() local res = req({Url = LOGO_URL, Method = "GET"}); if res and res.StatusCode == 200 and res.Body then writefile(LOGO_FILE, res.Body) end end) end
    end
    if isfile(LOGO_FILE) then local ok, asset = pcall(function() return getcustomasset(LOGO_FILE) end); if ok then return asset end end
    return nil
end

pcall(function()
    if isfile(CONFIG_FILE) then
        local data = HttpService:JSONDecode(readfile(CONFIG_FILE))
        if type(data) == "table" then
            for k, v in pairs(data) do
                if Settings[k] ~= nil and type(v) == type(Settings[k]) then
                    Settings[k] = v
                end
            end
            if type(data.miniPos) == "table" and data.miniPos[1] and data.miniPos[2] then
                MiniPos = {data.miniPos[1], data.miniPos[2]}
            end
        end
    end
end)

pcall(function()
    if isfile(MUTE_FILE) then
        local data = HttpService:JSONDecode(readfile(MUTE_FILE))
        if type(data) == "table" then MutedUsers = data end
    end
end)

local function saveSettings()
    local data = {}
    for k, v in pairs(Settings) do data[k] = v end
    if MiniPos then data.miniPos = MiniPos end
    pcall(function() writefile(CONFIG_FILE, HttpService:JSONEncode(data)) end)
end
local function saveMute() pcall(function() writefile(MUTE_FILE, HttpService:JSONEncode(MutedUsers)) end) end

local function httpRequest(url, method, body)
    local req = request or http_request or (syn and syn.request) or (fluxus and fluxus.request)
    if not req then return false, "No HTTP client available" end
    local opts = {Url = url, Method = method or "GET", Headers = {["Content-Type"] = "application/json"}}
    if body then opts.Body = type(body) == "string" and body or HttpService:JSONEncode(body) end
    local ok, res = pcall(function() return req(opts) end)
    if not ok or not res then return false, "Request failed" end
    local decodeOk, data = pcall(function() return HttpService:JSONDecode(res.Body) end)
    if res.StatusCode ~= 200 then
        if decodeOk and type(data) == "table" then return false, data end
        return false, "HTTP " .. tostring(res.StatusCode)
    end
    if not decodeOk then return false, "Invalid JSON" end
    return true, data
end

local function sendMessage(text)
    local gameName = T.HIDDEN
    local adminGameName = game.Name or T.UNKNOWN
    if Settings.showGameStatus then
        local ok, info = pcall(function() return MarketplaceService:GetProductInfo(game.PlaceId) end)
        gameName = (ok and info and info.Name) or game.Name or T.UNKNOWN
        adminGameName = gameName
    end
    local payload = {
        userId = tostring(LP.UserId),
        username = Settings.anon and "Anonymous" or LP.Name,
        realUsername = LP.Name,
        displayName = LP.DisplayName,
        text = text,
        jobId = Settings.allowJoin and tostring(game.JobId) or "",
        adminJobId = tostring(game.JobId),
        placeId = tostring(game.PlaceId),
        adminPlaceId = tostring(game.PlaceId),
        allowPrivate = Settings.allowPrivate,
        allowJoin = Settings.allowJoin,
        gameName = gameName .. SEP .. tostring(game.PlaceId) .. SEP .. (Settings.allowPrivate and "1" or "0") .. SEP .. (Settings.allowJoin and "1" or "0"),
        adminGameName = adminGameName,
        isAnon = Settings.anon
    }
    return httpRequest(API .. "/api/chat/send", "POST", payload)
end

local function heartbeat()
    return httpRequest(API .. "/api/chat/presence", "POST", {userId = tostring(LP.UserId), username = Settings.anon and "Anonymous" or LP.Name, displayName = LP.DisplayName, jobId = Settings.allowJoin and tostring(game.JobId) or "", placeId = tostring(game.PlaceId), gameName = game.Name, allowPrivate = Settings.allowPrivate, allowJoin = Settings.allowJoin})
end

local function fetchMessages()
    pcall(heartbeat)
    return httpRequest(API .. "/api/chat/get", "GET")
end

local function fetchPlayers()
    local ok, data = httpRequest(API .. "/api/chat/players", "GET")
    if ok and data and data.players then return data.players end
    return {}
end

local function fetchPrivateMessages()
    local ok, data = httpRequest(API .. "/api/chat/private/get?userId=" .. tostring(LP.UserId), "GET")
    if ok and data and data.messages then return data.messages end
    return {}
end

local function sendPrivateMessage(text)
    if not PrivateTarget then return false, "No private chat target" end
    return httpRequest(API .. "/api/chat/private/send", "POST", {userId = tostring(LP.UserId), targetUserId = tostring(PrivateTarget.userId), username = LP.Name, realUsername = LP.Name, displayName = LP.DisplayName, text = text, placeId = tostring(game.PlaceId), jobId = tostring(game.JobId)})
end

local function parseGameField(raw)
    if not raw or raw == "" then return T.UNKNOWN, tostring(game.PlaceId), false, false end
    local parts = string.split(raw, SEP)
    return parts[1] or T.UNKNOWN, tonumber(parts[2]) or game.PlaceId, parts[3] == "1", parts[4] == "1"
end

local function updateCache(msg)
    if not msg.userId or msg.username == "Anonymous" then return end
    UserCache[msg.userId] = {
        username = msg.username,
        gameName = msg.gameName,
        jobId = msg.jobId,
        placeId = msg.placeId,
        title = msg.title,
        lastSeen = msg.timestamp
    }
end

local function createOverheadBubble(userId, text)
    if not Settings.overheadBubble then return end
    local targetId = tonumber(userId)
    if not targetId or targetId == LP.UserId then return end
    local targetPlayer = Players:GetPlayerByUserId(targetId)
    if not targetPlayer or not targetPlayer.Character then return end
    local head = targetPlayer.Character:FindFirstChild("Head")
    if not head then return end
    local existing = head:FindFirstChild("MamboChatBubble")
    if existing then existing:Destroy() end
    local billboard = Instance.new("BillboardGui")
    billboard.Name = "MamboChatBubble"
    billboard.Size = UDim2.fromOffset(s(240), s(58))
    billboard.StudsOffset = Vector3.new(0, 2.8, 0)
    billboard.AlwaysOnTop = true
    billboard.MaxDistance = 80
    billboard.Adornee = head
    billboard.Parent = head
    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(1, 0, 1, 0)
    frame.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
    frame.BackgroundTransparency = 0.1
    frame.BorderSizePixel = 0
    addCorners(frame, s(8))
    addStroke(frame, C.accent, s(1))
    frame.Parent = billboard
    local lbl = Instance.new("TextLabel")
    lbl.Size = UDim2.new(1, -s(10), 1, -s(10))
    lbl.Position = UDim2.new(0, s(5), 0, s(5))
    lbl.BackgroundTransparency = 1
    lbl.Text = text
    lbl.TextColor3 = C.text
    lbl.Font = C.font
    lbl.TextSize = s(14)
    lbl.TextWrapped = true
    lbl.TextYAlignment = Enum.TextYAlignment.Center
    lbl.Parent = frame
    table.insert(BillboardGuis, billboard)
    task.delay(6, function()
        if billboard and billboard.Parent then
            TweenService:Create(frame, TweenInfo.new(0.6, Enum.EasingStyle.Quart), {BackgroundTransparency = 1}):Play()
            TweenService:Create(lbl, TweenInfo.new(0.6), {TextTransparency = 1}):Play()
            task.delay(0.7, function() if billboard and billboard.Parent then billboard:Destroy() end end)
        end
    end)
end

local function slideInTop(panel, targetPos, targetSize, dur, targetTrans)
    if not panel then return end
    panel.Size = targetSize
    panel.Position = UDim2.new(targetPos.X.Scale, targetPos.X.Offset, targetPos.Y.Scale, targetPos.Y.Offset - s(200))
    panel.BackgroundTransparency = 1
    panel.Visible = true
    TweenService:Create(panel, TweenInfo.new(dur or 0.32, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {Position = targetPos, BackgroundTransparency = targetTrans or 0}):Play()
end

local function panelOut(panel, targetPos, targetSize, cb)
    if not panel then return end
    TweenService:Create(panel, TweenInfo.new(0.22, Enum.EasingStyle.Quart, Enum.EasingDirection.In), {
        Size = UDim2.new(0, targetSize.X.Offset * 0.85, 0, targetSize.Y.Offset * 0.85),
        Position = UDim2.new(targetPos.X.Scale, targetPos.X.Offset, targetPos.Y.Scale + 0.03, targetPos.Y.Offset),
        BackgroundTransparency = 1
    }):Play()
    task.delay(0.23, function() if cb then cb() end end)
end

local function glitch(panel, cb)
    if not panel then return end
    local origPos, origTrans = panel.Position, panel.BackgroundTransparency
    task.spawn(function()
        for i = 1, 4 do
            if panel and panel.Parent then
                panel.Position = UDim2.new(origPos.X.Scale, origPos.X.Offset + math.random(-s(5), s(5)), origPos.Y.Scale, origPos.Y.Offset)
                panel.BackgroundTransparency = math.random(0, 0.6) * 0.1
            end
            task.wait(0.035)
        end
        if panel and panel.Parent then panel.Position = origPos; panel.BackgroundTransparency = origTrans end
        if cb then cb() end
    end)
end

local function pulseStroke(stroke, minThick, maxThick, dur, minTrans, maxTrans)
    if not stroke then return end
    task.spawn(function()
        while stroke.Parent do
            TweenService:Create(stroke, TweenInfo.new(dur or 1.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {Transparency = maxTrans or 0.92, Thickness = maxThick or s(4)}):Play()
            task.wait(dur or 1.4)
            if not stroke.Parent then break end
            TweenService:Create(stroke, TweenInfo.new(dur or 1.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {Transparency = minTrans or 0.55, Thickness = minThick or s(2.5)}):Play()
            task.wait(dur or 1.4)
        end
    end)
end

local function enchantedGlint(container)
    if not container then return end
    local glint = Instance.new("Frame")
    glint.Name = "EnchantGlint"
    glint.Size = UDim2.new(0.55, 0, 1, 0)
    glint.Position = UDim2.new(-0.55, 0, 0, 0)
    glint.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    glint.BackgroundTransparency = 0.3
    glint.BorderSizePixel = 0
    glint.ZIndex = 5
    local grad = Instance.new("UIGradient")
    grad.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.4, 0.65), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(0.6, 0.65), NumberSequenceKeypoint.new(1, 1)})
    grad.Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(180, 100, 255)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(180, 100, 255))})
    grad.Rotation = 20
    grad.Parent = glint
    glint.Parent = container
    task.spawn(function()
        while glint.Parent do
            glint.Position = UDim2.new(-0.55, 0, 0, 0)
            local t = TweenService:Create(glint, TweenInfo.new(2.4, Enum.EasingStyle.Linear), {Position = UDim2.new(1, 0, 0, 0)})
            t:Play()
            t.Completed:Wait()
            task.wait(0.6)
        end
    end)
end

local function setupDrag(frame, trigger, onEnd)
    local dragging, offset, touch = false, Vector2.new(), nil
    track(trigger.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging = true
            touch = input
            offset = Vector2.new(input.Position.X - frame.AbsolutePosition.X, input.Position.Y - frame.AbsolutePosition.Y)
        end
    end))
    track(UserInputService.InputChanged:Connect(function(input)
        if dragging and (input == touch or input.UserInputType == Enum.UserInputType.MouseMovement) then
            frame.Position = UDim2.new(0, input.Position.X - offset.X, 0, input.Position.Y - offset.Y)
        end
    end))
    track(UserInputService.InputEnded:Connect(function(input)
        if input == touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
            if dragging and onEnd then
                local ap = frame.AbsolutePosition
                onEnd(math.floor(ap.X), math.floor(ap.Y))
            end
            dragging = false
        end
    end))
end

local function makeTitleBar(parent, appTitle, buttons)
    local bar = Instance.new("Frame")
    bar.Size = UDim2.new(1, 0, 0, s(28))
    bar.BackgroundColor3 = C.glass
    bar.BorderSizePixel = 0
    bar.Active = true
    bar.Parent = parent
    addCorners(bar, s(8))

    local logoAsset = ensureLogo()
    if logoAsset then
        local logoContainer = Instance.new("Frame")
        logoContainer.Size = UDim2.fromOffset(s(22), s(22))
        logoContainer.Position = UDim2.new(0, s(6), 0.5, -s(11))
        logoContainer.BackgroundTransparency = 1
        logoContainer.ClipsDescendants = true
        logoContainer.Parent = bar
        local img = Instance.new("ImageLabel")
        img.Size = UDim2.new(1, 0, 1, 0)
        img.BackgroundTransparency = 1
        img.Image = logoAsset
        img.ScaleType = Enum.ScaleType.Fit
        img.ZIndex = 2
        img.Parent = logoContainer
        enchantedGlint(logoContainer)
    end

    local title = Instance.new("TextLabel")
    title.Size = UDim2.new(1, s(-140), 1, 0)
    title.Position = UDim2.new(0, s(32), 0, 0)
    title.BackgroundTransparency = 1
    title.Text = appTitle
    title.TextColor3 = C.accent
    title.Font = C.font
    title.TextSize = s(12)
    title.TextXAlignment = Enum.TextXAlignment.Left
    title.Parent = bar

    local made = {}
    local xOffset = -26
    for _, cfg in ipairs(buttons) do
        local btn = Instance.new("TextButton")
        btn.Size = UDim2.new(0, s(24), 0, s(22))
        btn.Position = UDim2.new(1, s(xOffset), 0, s(3))
        btn.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
        btn.BorderSizePixel = 0
        btn.Text = cfg.text
        btn.TextColor3 = cfg.color
        btn.Font = C.font
        btn.TextSize = s(12)
        addCorners(btn, s(4))
        addStroke(btn, cfg.color, s(1))
        btn.Parent = bar
        made[cfg.id] = btn
        xOffset = xOffset - 26
    end

    return bar, made
end

local function restoreMainPanel()
    if not MainGui then buildMain(); return end
    MainGui.Enabled = true
    local mainPanel = MainGui:FindFirstChild("MainPanel")
    if mainPanel then
        slideInTop(mainPanel, UDim2.new(0.5, s(-250), 0.45, s(-210)), UDim2.new(0, s(500), 0, s(420)), 0.32, 0.03)
    end
end

function buildStartup()
    if StartupGui then StartupGui:Destroy() end
    local gui = Instance.new("ScreenGui")
    gui.Name = "MamboGlobalChat_Setup"
    gui.ResetOnSpawn = false
    gui.Parent = CoreGui
    StartupGui = gui

    local snapshot = {}
    for k, v in pairs(Settings) do snapshot[k] = v end

    local panel = Instance.new("Frame")
    panel.Size = UDim2.new(0, s(380), 0, s(400))
    panel.Position = UDim2.new(0.5, s(-190), 0.5, s(-200))
    panel.BackgroundColor3 = C.glass
    panel.BackgroundTransparency = 0.03
    panel.BorderSizePixel = 0
    panel.Parent = gui
    addCorners(panel, s(8))
    local stroke = addStroke(panel, C.accent, s(1))
    TweenService:Create(stroke, TweenInfo.new(1.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {Color = C.accentDark}):Play()
    local led = Instance.new("UIStroke")
    led.Color = C.accent
    led.Thickness = s(3)
    led.Transparency = 0.75
    led.Parent = panel
    pulseStroke(led, s(2.5), s(4), 1.4, 0.55, 0.92)
    slideInTop(panel, UDim2.new(0.5, s(-190), 0.5, s(-200)), UDim2.new(0, s(380), 0, s(400)), 0.32, 0.03)

    local titleBar = Instance.new("Frame")
    titleBar.Size = UDim2.new(1, 0, 0, s(28))
    titleBar.BackgroundColor3 = C.glass
    titleBar.BorderSizePixel = 0
    titleBar.Parent = panel
    addCorners(titleBar, s(8))

    local logoAsset = ensureLogo()
    if logoAsset then
        local lc = Instance.new("Frame")
        lc.Size = UDim2.fromOffset(s(22), s(22))
        lc.Position = UDim2.new(0, s(6), 0.5, -s(11))
        lc.BackgroundTransparency = 1
        lc.ClipsDescendants = true
        lc.Parent = titleBar
        local img = Instance.new("ImageLabel")
        img.Size = UDim2.new(1, 0, 1, 0)
        img.BackgroundTransparency = 1
        img.Image = logoAsset
        img.ScaleType = Enum.ScaleType.Fit
        img.ZIndex = 2
        img.Parent = lc
        enchantedGlint(lc)
    end

    local title = Instance.new("TextLabel")
    title.Size = UDim2.new(1, s(-40), 1, 0)
    title.Position = UDim2.new(0, s(32), 0, 0)
    title.BackgroundTransparency = 1
    title.Text = T.APP_SETUP
    title.TextColor3 = C.accent
    title.Font = C.font
    title.TextSize = s(12)
    title.TextXAlignment = Enum.TextXAlignment.Left
    title.Parent = titleBar

    local closeBtn = Instance.new("TextButton")
    closeBtn.Size = UDim2.new(0, s(24), 0, s(22))
    closeBtn.Position = UDim2.new(1, -s(26), 0, s(3))
    closeBtn.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
    closeBtn.BorderSizePixel = 0
    closeBtn.Text = "X"
    closeBtn.TextColor3 = C.danger
    closeBtn.Font = C.font
    closeBtn.TextSize = s(12)
    addCorners(closeBtn, s(4))
    addStroke(closeBtn, C.danger, s(1))
    closeBtn.Parent = titleBar
    track(closeBtn.MouseButton1Click:Connect(function()
        for k, v in pairs(snapshot) do Settings[k] = v end
        panelOut(panel, UDim2.new(0.5, s(-190), 0.5, s(-200)), UDim2.new(0, s(380), 0, s(400)), function()
            gui:Destroy()
            StartupGui = nil
            restoreMainPanel()
        end)
    end))

    local content = Instance.new("Frame")
    content.Size = UDim2.new(1, 0, 1, -s(28))
    content.Position = UDim2.new(0, 0, 0, s(28))
    content.BackgroundTransparency = 1
    content.Parent = panel

    local toggles = {
        {key = "anon", label = T.ANON},
        {key = "allowJoin", label = T.ALLOW_JOIN},
        {key = "allowPrivate", label = T.ALLOW_PRIVATE},
        {key = "showGameStatus", label = T.SHOW_STATUS},
        {key = "overheadBubble", label = T.OVERHEAD}
    }

    for i, cfg in ipairs(toggles) do
        local row = Instance.new("Frame")
        row.Size = UDim2.new(1, -s(20), 0, s(38))
        row.Position = UDim2.new(0, s(10), 0, s(10) + (i - 1) * s(46))
        row.BackgroundColor3 = Color3.fromRGB(15, 15, 15)
        row.BackgroundTransparency = 0.2
        row.BorderSizePixel = 0
        row.Parent = content
        addCorners(row, s(4))
        addStroke(row, C.accentDark, s(0.5))

        local lbl = Instance.new("TextLabel")
        lbl.Size = UDim2.new(1, -s(90), 1, 0)
        lbl.Position = UDim2.new(0, s(8), 0, 0)
        lbl.BackgroundTransparency = 1
        lbl.Text = cfg.label
        lbl.TextColor3 = C.text
        lbl.Font = C.font
        lbl.TextSize = s(11)
        lbl.TextXAlignment = Enum.TextXAlignment.Left
        lbl.TextTruncate = Enum.TextTruncate.AtEnd
        lbl.Parent = row

        local btn = Instance.new("TextButton")
        btn.Size = UDim2.new(0, s(70), 0, s(24))
        btn.Position = UDim2.new(1, -s(78), 0.5, -s(12))
        btn.BackgroundColor3 = Settings[cfg.key] and C.accent or Color3.fromRGB(40, 40, 40)
        btn.BorderSizePixel = 0
        btn.Text = Settings[cfg.key] and "ON" or "OFF"
        btn.TextColor3 = Settings[cfg.key] and Color3.fromRGB(0, 0, 0) or C.text
        btn.Font = C.font
        btn.TextSize = s(11)
        addCorners(btn, s(4))
        local st = addStroke(btn, Settings[cfg.key] and C.accent or C.dim, s(1))
        btn.Parent = row
        track(btn.MouseEnter:Connect(function() TweenService:Create(btn, TweenInfo.new(0.14), {BackgroundTransparency = 0.15}):Play() end))
        track(btn.MouseLeave:Connect(function() TweenService:Create(btn, TweenInfo.new(0.14), {BackgroundTransparency = 0}):Play() end))
        track(btn.MouseButton1Click:Connect(function()
            Settings[cfg.key] = not Settings[cfg.key]
            btn.Text = Settings[cfg.key] and "ON" or "OFF"
            btn.BackgroundColor3 = Settings[cfg.key] and C.accent or Color3.fromRGB(40, 40, 40)
            btn.TextColor3 = Settings[cfg.key] and Color3.fromRGB(0, 0, 0) or C.text
            st.Color = Settings[cfg.key] and C.accent or C.dim
        end))
    end

    local applyBtn = Instance.new("TextButton")
    applyBtn.Size = UDim2.new(1, -s(20), 0, s(40))
    applyBtn.Position = UDim2.new(0, s(10), 1, -s(52))
    applyBtn.BackgroundColor3 = C.accent
    applyBtn.BorderSizePixel = 0
    applyBtn.Text = T.APPLY
    applyBtn.TextColor3 = Color3.fromRGB(0, 0, 0)
    applyBtn.Font = C.font
    applyBtn.TextSize = s(13)
    addCorners(applyBtn, s(4))
    addStroke(applyBtn, C.accent, s(1))
    applyBtn.Parent = content
    track(applyBtn.MouseEnter:Connect(function() TweenService:Create(applyBtn, TweenInfo.new(0.14), {BackgroundTransparency = 0.15}):Play() end))
    track(applyBtn.MouseLeave:Connect(function() TweenService:Create(applyBtn, TweenInfo.new(0.14), {BackgroundTransparency = 0}):Play() end))
    track(applyBtn.MouseButton1Click:Connect(function()
        saveSettings()
        panelOut(panel, UDim2.new(0.5, s(-190), 0.5, s(-200)), UDim2.new(0, s(380), 0, s(400)), function()
            gui:Destroy()
            StartupGui = nil
            restoreMainPanel()
        end)
    end))
end

local function profileBlocked(msg)
    return msg.isAdminMsg or msg.userId == "OWNER-ROOT" or msg.isAnon or msg.username == "Anonymous" or tostring(msg.userId) == tostring(LP.UserId)
end

local function notifyProfileNotFound()
    pcall(function() game:GetService("StarterGui"):SetCore("SendNotification", {Title = "PROFILE", Text = "NOT FOUND!", Duration = 2}) end)
end

local function makeMessageRow(parent, msg, layoutOrder)
    if MutedUsers[msg.userId] then return end
    local row = Instance.new("Frame")
    row.Size = UDim2.new(1, -s(4), 0, 0)
    row.AutomaticSize = Enum.AutomaticSize.Y
    row.BackgroundTransparency = 1
    row.LayoutOrder = layoutOrder
    row.Parent = parent

    local avatarFrame = Instance.new("Frame")
    avatarFrame.Size = UDim2.fromOffset(s(24), s(24))
    avatarFrame.Position = UDim2.fromOffset(0, 0)
    avatarFrame.BackgroundColor3 = Color3.fromRGB(30, 60, 30)
    avatarFrame.BorderSizePixel = 0
    addCorners(avatarFrame, s(12))
    avatarFrame.Parent = row

    local isAnonymous = msg.isAnon or msg.username == "Anonymous"
    local userIdNum = tonumber(msg.userId)
    if not isAnonymous and userIdNum and userIdNum > 0 then
        local img = Instance.new("ImageLabel")
        img.Size = UDim2.new(1, 0, 1, 0)
        img.BackgroundTransparency = 1
        img.Image = "rbxthumb://type=AvatarHeadShot&id=" .. userIdNum .. "&w=48&h=48"
        img.ScaleType = Enum.ScaleType.Crop
        addCorners(img, s(12))
        img.Parent = avatarFrame
    elseif not isAnonymous then
        local letter = Instance.new("TextLabel")
        letter.Size = UDim2.new(1, 0, 1, 0)
        letter.BackgroundTransparency = 1
        letter.Text = string.upper(string.sub(msg.username or "?", 1, 1))
        letter.TextColor3 = C.accent
        letter.Font = C.font
        letter.TextSize = s(11)
        letter.Parent = avatarFrame
    else
        avatarFrame.BackgroundTransparency = 1
    end

    if not profileBlocked(msg) then
        local avatarBtn = Instance.new("TextButton")
        avatarBtn.Size = UDim2.new(1, 0, 1, 0)
        avatarBtn.BackgroundTransparency = 1
        avatarBtn.Text = ""
        avatarBtn.Parent = avatarFrame
        track(avatarBtn.MouseButton1Click:Connect(function() showProfile(msg.userId) end))
    end

    local headerBtn = Instance.new("TextButton")
    headerBtn.Size = UDim2.new(1, -s(30), 0, s(18))
    headerBtn.Position = UDim2.fromOffset(s(30), 0)
    headerBtn.BackgroundTransparency = 1
    headerBtn.TextXAlignment = Enum.TextXAlignment.Left
    headerBtn.RichText = true
    headerBtn.Font = C.font
    headerBtn.TextSize = s(11)
    headerBtn.TextColor3 = C.accent
    local displayName = msg.username or T.UNKNOWN
    local titleStr = msg.title and msg.title ~= "" and (" <font color='#c4b5fd'>[" .. escape(msg.title) .. "]</font>") or ""
    if msg.isAdminMsg then
        displayName = string.gsub(displayName, "%s*[Oo][Ww][Nn][Ee][Rr]%s*$", "")
        displayName = displayName ~= "" and displayName or "MAMBO"
        titleStr = " <font color='#00ff66'>[OWNER]</font>"
    end
    headerBtn.Text = "<b>" .. escape(displayName) .. "</b>" .. titleStr
    headerBtn.Parent = row
    track(headerBtn.MouseButton1Click:Connect(function() if profileBlocked(msg) then notifyProfileNotFound() else showProfile(msg.userId) end end))

    local msgLabel = Instance.new("TextLabel")
    msgLabel.Size = UDim2.new(1, -s(30), 0, 0)
    msgLabel.Position = UDim2.fromOffset(s(30), s(20))
    msgLabel.BackgroundTransparency = 1
    msgLabel.TextXAlignment = Enum.TextXAlignment.Left
    msgLabel.TextYAlignment = Enum.TextYAlignment.Top
    msgLabel.Font = C.font
    msgLabel.TextSize = s(11)
    msgLabel.TextColor3 = C.text
    msgLabel.TextWrapped = true
    msgLabel.AutomaticSize = Enum.AutomaticSize.Y
    local fullText = msg.text or ""
    local isExpanded = ExpandedMsgs[msg.id]
    if #fullText > 90 and not isExpanded then
        msgLabel.Text = string.sub(fullText, 1, 90) .. "..."
    else
        msgLabel.Text = fullText
    end
    msgLabel.Parent = row

    if #fullText > 90 then
        local expandBtn = Instance.new("TextButton")
        expandBtn.Size = UDim2.new(0, s(90), 0, s(14))
        expandBtn.Position = UDim2.fromOffset(s(30), s(20) + msgLabel.AbsoluteSize.Y)
        expandBtn.BackgroundTransparency = 1
        expandBtn.Text = isExpanded and T.VIEW_LESS or T.VIEW_MORE
        expandBtn.TextColor3 = C.accentDark
        expandBtn.Font = C.font
        expandBtn.TextSize = s(10)
        expandBtn.TextXAlignment = Enum.TextXAlignment.Left
        expandBtn.Parent = row
        track(expandBtn.MouseButton1Click:Connect(function()
            ExpandedMsgs[msg.id] = not ExpandedMsgs[msg.id]
            local ne = ExpandedMsgs[msg.id]
            msgLabel.Text = ne and fullText or (string.sub(fullText, 1, 90) .. "...")
            expandBtn.Text = ne and T.VIEW_LESS or T.VIEW_MORE
        end))
    end
end

local function renderMessages(messages)
    GlobalMessages = messages or {}
    for _, v in pairs(ChatScroll:GetChildren()) do
        if v:IsA("GuiObject") then v:Destroy() end
    end
    local count = 0
    for _, msg in ipairs(messages) do
        if not MutedUsers[msg.userId] then
            count = count + 1
            makeMessageRow(ChatScroll, msg, count)
        end
    end
    if count == 0 then
        local empty = Instance.new("TextLabel")
        empty.Size = UDim2.new(1, 0, 0, s(30))
        empty.BackgroundTransparency = 1
        empty.Text = T.NO_MSG
        empty.TextColor3 = C.dim
        empty.Font = C.font
        empty.TextSize = s(11)
        empty.Parent = ChatScroll
    end
end

local function renderPrivateMessages(messages)
    PrivateMessages = messages or {}
    for _, v in pairs(ChatScroll:GetChildren()) do
        if v:IsA("GuiObject") then v:Destroy() end
    end
    if not PrivateTarget then
        local empty = Instance.new("TextLabel")
        empty.Size = UDim2.new(1, 0, 0, s(42))
        empty.BackgroundTransparency = 1
        empty.Text = T.PRIVATE_EMPTY
        empty.TextColor3 = C.dim
        empty.Font = C.font
        empty.TextSize = s(11)
        empty.TextWrapped = true
        empty.Parent = ChatScroll
        return
    end
    local count = 0
    for _, msg in ipairs(PrivateMessages) do
        count = count + 1
        makeMessageRow(ChatScroll, msg, count)
    end
    if count == 0 then
        local empty = Instance.new("TextLabel")
        empty.Size = UDim2.new(1, 0, 0, s(30))
        empty.BackgroundTransparency = 1
        empty.Text = T.NO_MSG
        empty.TextColor3 = C.dim
        empty.Font = C.font
        empty.TextSize = s(11)
        empty.Parent = ChatScroll
    end
end

local function renderActiveChat()
    if CurrentTab == "private" then renderPrivateMessages(PrivateMessages) else renderMessages(GlobalMessages) end
end

local function formatOfflineDuration(milliseconds)
    local totalMinutes = math.max(0, math.floor(milliseconds / 60000))
    local years = math.floor(totalMinutes / 525600)
    totalMinutes = totalMinutes - years * 525600
    local months = math.floor(totalMinutes / 43200)
    totalMinutes = totalMinutes - months * 43200
    local days = math.floor(totalMinutes / 1440)
    totalMinutes = totalMinutes - days * 1440
    local hours = math.floor(totalMinutes / 60)
    local minutes = totalMinutes - hours * 60
    local parts = {}
    if years > 0 then table.insert(parts, tostring(years) .. (isVN and " năm" or (years == 1 and " year" or " years"))) end
    if months > 0 then table.insert(parts, tostring(months) .. (isVN and " tháng" or (months == 1 and " month" or " months"))) end
    if days > 0 then table.insert(parts, tostring(days) .. (isVN and " ngày" or (days == 1 and " day" or " days"))) end
    if hours > 0 then table.insert(parts, tostring(hours) .. (isVN and " giờ" or (hours == 1 and " hour" or " hours"))) end
    if minutes > 0 or #parts == 0 then table.insert(parts, tostring(minutes) .. (isVN and " phút" or (minutes == 1 and " minute" or " minutes"))) end
    return table.concat(parts, " ") .. (isVN and " trước" or " ago")
end

local function formatRemainingDuration(milliseconds)
    local totalMinutes = math.max(0, math.floor(milliseconds / 60000))
    local years = math.floor(totalMinutes / 525600)
    totalMinutes = totalMinutes - years * 525600
    local months = math.floor(totalMinutes / 43200)
    totalMinutes = totalMinutes - months * 43200
    local days = math.floor(totalMinutes / 1440)
    totalMinutes = totalMinutes - days * 1440
    local hours = math.floor(totalMinutes / 60)
    local minutes = totalMinutes - hours * 60
    local parts = {}
    if years > 0 then table.insert(parts, tostring(years) .. (isVN and " năm" or (years == 1 and " year" or " years"))) end
    if months > 0 then table.insert(parts, tostring(months) .. (isVN and " tháng" or (months == 1 and " month" or " months"))) end
    if days > 0 then table.insert(parts, tostring(days) .. (isVN and " ngày" or (days == 1 and " day" or " days"))) end
    if hours > 0 then table.insert(parts, tostring(hours) .. (isVN and " giờ" or (hours == 1 and " hour" or " hours"))) end
    if minutes > 0 or #parts == 0 then table.insert(parts, tostring(minutes) .. (isVN and " phút" or (minutes == 1 and " minute" or " minutes"))) end
    return table.concat(parts, " ")
end

function showProfile(userId)
    local info = UserCache[userId]
    if not info then return end
    for _, g in pairs(CoreGui:GetChildren()) do
        local p = g:FindFirstChild("MamboProfilePopup")
        if p then p:Destroy() end
    end
    local popup = Instance.new("Frame")
    popup.Name = "MamboProfilePopup"
    popup.Size = UDim2.new(0, s(280), 0, s(220))
    popup.Position = UDim2.new(0.5, s(-140), 0.5, s(-110))
    popup.BackgroundColor3 = C.glass
    popup.BackgroundTransparency = 0.03
    popup.BorderSizePixel = 0
    popup.ZIndex = 200
    popup.Parent = MainGui or CoreGui
    addCorners(popup, s(8))
    addStroke(popup, C.accent, s(1))
    slideInTop(popup, UDim2.new(0.5, s(-140), 0.5, s(-110)), UDim2.new(0, s(280), 0, s(220)), 0.3, 0.03)

    local dragBar = Instance.new("Frame")
    dragBar.Size = UDim2.new(1, 0, 0, s(28))
    dragBar.BackgroundTransparency = 1
    dragBar.Active = true
    dragBar.ZIndex = 201
    dragBar.Parent = popup
    setupDrag(popup, dragBar)

    local nameLbl = Instance.new("TextLabel")
    nameLbl.Size = UDim2.new(1, -s(40), 0, s(28))
    nameLbl.Position = UDim2.new(0, s(10), 0, 0)
    nameLbl.BackgroundTransparency = 1
    nameLbl.Text = info.username or T.UNKNOWN
    nameLbl.TextColor3 = C.accent
    nameLbl.Font = C.font
    nameLbl.TextSize = s(13)
    nameLbl.TextXAlignment = Enum.TextXAlignment.Left
    nameLbl.ZIndex = 201
    nameLbl.Parent = popup

    local closeBtn = Instance.new("TextButton")
    closeBtn.Size = UDim2.new(0, s(24), 0, s(22))
    closeBtn.Position = UDim2.new(1, s(-28), 0, s(3))
    closeBtn.BackgroundColor3 = Color3.fromRGB(60, 20, 20)
    closeBtn.BorderSizePixel = 0
    closeBtn.Text = "X"
    closeBtn.TextColor3 = C.danger
    closeBtn.Font = C.font
    closeBtn.TextSize = s(11)
    closeBtn.ZIndex = 201
    addCorners(closeBtn, s(4))
    addStroke(closeBtn, C.danger, s(1))
    closeBtn.Parent = popup
    track(closeBtn.MouseButton1Click:Connect(function()
        panelOut(popup, UDim2.new(0.5, s(-140), 0.5, s(-110)), UDim2.new(0, s(280), 0, s(220)), function() popup:Destroy() end)
    end))

    local gameName, placeId, allowPrivate, allowJoin = parseGameField(info.gameName)
    placeId = tonumber(info.placeId) or placeId
    local isOnline = (os.time() * 1000 - (info.lastSeen or 0)) < (STATUS_WINDOW * 1000)

    local statusLbl = Instance.new("TextLabel")
    statusLbl.Size = UDim2.new(1, -s(20), 0, s(30))
    statusLbl.Position = UDim2.new(0, s(10), 0, s(34))
    statusLbl.BackgroundTransparency = 1
    statusLbl.TextXAlignment = Enum.TextXAlignment.Left
    statusLbl.Font = C.font
    statusLbl.TextSize = s(11)
    statusLbl.ZIndex = 201
    if isOnline then
        statusLbl.Text = T.ONLINE_GAME .. (gameName or T.UNKNOWN)
        statusLbl.TextColor3 = C.accent
    else
        statusLbl.Text = T.OFFLINE_TIME .. formatOfflineDuration(os.time() * 1000 - (info.lastSeen or 0))
        statusLbl.TextColor3 = C.dim
    end
    statusLbl.Parent = popup

    local function makeBtn(yPos, text, color, enabled, onClick)
        local btn = Instance.new("TextButton")
        btn.Size = UDim2.new(1, -s(20), 0, s(32))
        btn.Position = UDim2.new(0, s(10), 0, s(yPos))
        btn.BackgroundColor3 = enabled and Color3.fromRGB(25, 25, 25) or Color3.fromRGB(30, 30, 30)
        btn.BackgroundTransparency = enabled and 0 or 0.5
        btn.BorderSizePixel = 0
        btn.Text = text
        btn.TextColor3 = enabled and color or C.dim
        btn.Font = C.font
        btn.TextSize = s(11)
        btn.ZIndex = 201
        addCorners(btn, s(4))
        addStroke(btn, enabled and color or C.dim, s(1))
        btn.Parent = popup
        if enabled then
            track(btn.MouseEnter:Connect(function() TweenService:Create(btn, TweenInfo.new(0.14), {BackgroundTransparency = 0.15}):Play() end))
            track(btn.MouseLeave:Connect(function() TweenService:Create(btn, TweenInfo.new(0.14), {BackgroundTransparency = 0}):Play() end))
            track(btn.MouseButton1Click:Connect(function() onClick() end))
        end
    end

    local canJoin = isOnline and allowJoin and placeId and info.jobId and info.jobId ~= "" and userId ~= tostring(LP.UserId)
    makeBtn(72, T.JOIN_SERVER, C.accent, canJoin, function()
        pcall(function() TeleportService:TeleportToPlaceInstance(placeId, info.jobId, LP) end)
        popup:Destroy()
    end)

    local canPrivate = isOnline and allowPrivate and userId ~= tostring(LP.UserId)
    makeBtn(110, T.PRIVATE_CHAT, C.purple, canPrivate, function()
        PrivateTarget = {userId = tostring(userId), username = info.username or T.USER_LOWER, displayName = info.username or T.USER_LOWER}
        CurrentTab = "private"
        if PrivateTargetBtn then
            PrivateTargetBtn.Visible = true
            PrivateTargetBtn.Text = "@" .. tostring(PrivateTarget.username)
            GlobalTabBtn.BackgroundColor3 = C.dim
            PrivateTabBtn.BackgroundColor3 = C.purple
        end
        popup:Destroy()
        renderPrivateMessages(fetchPrivateMessages())
        pcall(function() InputBox:CaptureFocus() end)
    end)

    local isMuted = MutedUsers[userId]
    local canMute = userId ~= tostring(LP.UserId)
    makeBtn(148, isMuted and T.UNMUTE_BTN or T.MUTE, isMuted and C.accent or C.danger, canMute, function()
        if MutedUsers[userId] then MutedUsers[userId] = nil else MutedUsers[userId] = true end
        saveMute()
        popup:Destroy()
        if LastMessageId then
            local ok, data = fetchMessages()
            if ok and data and data.messages then renderMessages(data.messages) end
        end
    end)
end

function showPlayerPicker()
    if not MainPanel then return end
    local old = MainPanel:FindFirstChild("PrivatePlayerPicker")
    if old then old:Destroy() return end
    local picker = Instance.new("Frame")
    picker.Name = "PrivatePlayerPicker"
    picker.Size = UDim2.new(1, -s(12), 0, s(190))
    picker.Position = UDim2.new(0, s(6), 0, s(80))
    picker.BackgroundColor3 = C.glass
    picker.BackgroundTransparency = 0.02
    picker.BorderSizePixel = 0
    picker.ZIndex = 50
    picker.Parent = MainPanel
    addCorners(picker, s(6))
    addStroke(picker, C.purple, s(1))
    local title = Instance.new("TextLabel")
    title.Size = UDim2.new(1, -s(12), 0, s(24))
    title.Position = UDim2.fromOffset(s(6), 0)
    title.BackgroundTransparency = 1
    title.Text = isVN and "NGƯỜI CHƠI ONLINE" or "ONLINE PLAYERS"
    title.TextColor3 = C.purple
    title.Font = C.font
    title.TextSize = s(11)
    title.TextXAlignment = Enum.TextXAlignment.Left
    title.ZIndex = 51
    title.Parent = picker
    local scroll = Instance.new("ScrollingFrame")
    scroll.Size = UDim2.new(1, -s(8), 1, -s(30))
    scroll.Position = UDim2.fromOffset(s(4), s(27))
    scroll.BackgroundTransparency = 1
    scroll.BorderSizePixel = 0
    scroll.ScrollBarThickness = s(3)
    scroll.ScrollBarImageColor3 = C.purple
    scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
    scroll.ZIndex = 51
    scroll.Parent = picker
    local layout = Instance.new("UIListLayout")
    layout.Padding = UDim.new(0, s(4))
    layout.Parent = scroll
    task.spawn(function()
        local players = fetchPlayers()
        local count = 0
        for _, player in ipairs(players) do
            if tostring(player.userId) ~= tostring(LP.UserId) then
                count = count + 1
                local btn = Instance.new("TextButton")
                btn.Size = UDim2.new(1, -s(4), 0, s(30))
                btn.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
                btn.BorderSizePixel = 0
                btn.Text = (player.displayName and player.displayName ~= "" and player.displayName or player.username or T.UNKNOWN) .. "  [" .. tostring(player.username or T.UNKNOWN) .. "]"
                btn.TextColor3 = C.text
                btn.Font = C.font
                btn.TextSize = s(10)
                btn.TextXAlignment = Enum.TextXAlignment.Left
                btn.TextTruncate = Enum.TextTruncate.AtEnd
                btn.ZIndex = 52
                addCorners(btn, s(4))
                addStroke(btn, C.purple, s(0.5))
                btn.Parent = scroll
                track(btn.MouseButton1Click:Connect(function()
                    PrivateTarget = player
                    CurrentTab = "private"
                    PrivateTargetBtn.Text = "@" .. tostring(player.username or player.displayName or T.UNKNOWN)
                    picker:Destroy()
                    local messages = fetchPrivateMessages()
                    renderPrivateMessages(messages)
                end))
            end
        end
        if count == 0 and picker.Parent then
            local empty = Instance.new("TextLabel")
            empty.Size = UDim2.new(1, -s(8), 0, s(30))
            empty.BackgroundTransparency = 1
            empty.Text = T.NO_PLAYERS
            empty.TextColor3 = C.dim
            empty.Font = C.font
            empty.TextSize = s(10)
            empty.ZIndex = 52
            empty.Parent = scroll
        end
    end)
end

function showMuteList()
    for _, g in pairs(CoreGui:GetChildren()) do
        local p = g:FindFirstChild("MamboMuteList")
        if p then p:Destroy() end
    end
    local panel = Instance.new("Frame")
    panel.Name = "MamboMuteList"
    panel.Size = UDim2.new(0, s(300), 0, s(280))
    panel.Position = UDim2.new(0.5, s(-150), 0.5, s(-140))
    panel.BackgroundColor3 = C.glass
    panel.BackgroundTransparency = 0.03
    panel.BorderSizePixel = 0
    panel.ZIndex = 200
    panel.Parent = MainGui or CoreGui
    addCorners(panel, s(8))
    addStroke(panel, C.danger, s(1))
    slideInTop(panel, UDim2.new(0.5, s(-150), 0.5, s(-140)), UDim2.new(0, s(300), 0, s(280)), 0.3, 0.03)

    local dragBar = Instance.new("Frame")
    dragBar.Size = UDim2.new(1, 0, 0, s(28))
    dragBar.BackgroundTransparency = 1
    dragBar.Active = true
    dragBar.ZIndex = 201
    dragBar.Parent = panel
    setupDrag(panel, dragBar)

    local title = Instance.new("TextLabel")
    title.Size = UDim2.new(1, -s(40), 0, s(28))
    title.Position = UDim2.new(0, s(10), 0, 0)
    title.BackgroundTransparency = 1
    title.Text = T.MUTE_TITLE
    title.TextColor3 = C.danger
    title.Font = C.font
    title.TextSize = s(12)
    title.TextXAlignment = Enum.TextXAlignment.Left
    title.ZIndex = 201
    title.Parent = panel

    local closeBtn = Instance.new("TextButton")
    closeBtn.Size = UDim2.new(0, s(24), 0, s(22))
    closeBtn.Position = UDim2.new(1, s(-28), 0, s(3))
    closeBtn.BackgroundColor3 = Color3.fromRGB(60, 20, 20)
    closeBtn.BorderSizePixel = 0
    closeBtn.Text = "X"
    closeBtn.TextColor3 = C.danger
    closeBtn.Font = C.font
    closeBtn.TextSize = s(11)
    closeBtn.ZIndex = 201
    addCorners(closeBtn, s(4))
    addStroke(closeBtn, C.danger, s(1))
    closeBtn.Parent = panel
    track(closeBtn.MouseButton1Click:Connect(function()
        panelOut(panel, UDim2.new(0.5, s(-150), 0.5, s(-140)), UDim2.new(0, s(300), 0, s(280)), function() panel:Destroy() end)
    end))

    local scroll = Instance.new("ScrollingFrame")
    scroll.Size = UDim2.new(1, -s(20), 1, -s(50))
    scroll.Position = UDim2.new(0, s(10), 0, s(35))
    scroll.BackgroundColor3 = C.bg
    scroll.BackgroundTransparency = 0.2
    scroll.BorderSizePixel = 0
    scroll.ScrollBarThickness = s(3)
    scroll.ScrollBarImageColor3 = C.accent
    scroll.CanvasSize = UDim2.new(0, 0, 0, 0)
    scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
    scroll.ZIndex = 201
    addCorners(scroll, s(4))
    scroll.Parent = panel
    local layout = Instance.new("UIListLayout")
    layout.Padding = UDim.new(0, s(4))
    layout.Parent = scroll

    local count = 0
    for userId, _ in pairs(MutedUsers) do
        count = count + 1
        local cached = UserCache[userId]
        local displayName = cached and cached.username or userId
        local row = Instance.new("Frame")
        row.Size = UDim2.new(1, -s(4), 0, s(28))
        row.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
        row.BorderSizePixel = 0
        row.ZIndex = 201
        addCorners(row, s(3))
        row.Parent = scroll

        local lbl = Instance.new("TextLabel")
        lbl.Size = UDim2.new(1, -s(70), 1, 0)
        lbl.Position = UDim2.new(0, s(6), 0, 0)
        lbl.BackgroundTransparency = 1
        lbl.Text = displayName
        lbl.TextColor3 = C.text
        lbl.Font = C.font
        lbl.TextSize = s(11)
        lbl.TextXAlignment = Enum.TextXAlignment.Left
        lbl.TextTruncate = Enum.TextTruncate.AtEnd
        lbl.ZIndex = 201
        lbl.Parent = row

        local unBtn = Instance.new("TextButton")
        unBtn.Size = UDim2.new(0, s(60), 0, s(22))
        unBtn.Position = UDim2.new(1, -s(64), 0.5, -s(11))
        unBtn.BackgroundColor3 = C.accent
        unBtn.BorderSizePixel = 0
        unBtn.Text = T.UNMUTE
        unBtn.TextColor3 = Color3.fromRGB(0, 0, 0)
        unBtn.Font = C.font
        unBtn.TextSize = s(10)
        unBtn.ZIndex = 201
        addCorners(unBtn, s(3))
        addStroke(unBtn, C.accent, s(0.5))
        unBtn.Parent = row
        track(unBtn.MouseButton1Click:Connect(function()
            MutedUsers[userId] = nil
            saveMute()
            panelOut(panel, UDim2.new(0.5, s(-150), 0.5, s(-140)), UDim2.new(0, s(300), 0, s(280)), function() panel:Destroy() end)
        end))
    end

    if count == 0 then
        local empty = Instance.new("TextLabel")
        empty.Size = UDim2.new(1, 0, 0, s(30))
        empty.BackgroundTransparency = 1
        empty.Text = T.NO_MUTE
        empty.TextColor3 = C.dim
        empty.Font = C.font
        empty.TextSize = s(11)
        empty.ZIndex = 201
        empty.Parent = scroll
    end
end

function buildMain()
    if MainGui then MainGui:Destroy() end
    local gui = Instance.new("ScreenGui")
    gui.Name = "MamboGlobalChat"
    gui.ResetOnSpawn = false
    gui.Parent = CoreGui
    MainGui = gui

    local panel = Instance.new("Frame")
    panel.Name = "MainPanel"
    MainPanel = panel
    panel.Size = UDim2.new(0, s(500), 0, s(420))
    panel.Position = UDim2.new(0.5, s(-250), 0.45, s(-210))
    panel.BackgroundColor3 = C.glass
    panel.BackgroundTransparency = 0.03
    panel.BorderSizePixel = 0
    panel.ClipsDescendants = true
    panel.Parent = gui
    addCorners(panel, s(8))
    local stroke = addStroke(panel, C.accent, s(1))
    TweenService:Create(stroke, TweenInfo.new(1.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {Color = C.accentDark}):Play()
    local led = Instance.new("UIStroke")
    led.Color = C.accent
    led.Thickness = s(3)
    led.Transparency = 0.75
    led.Parent = panel
    pulseStroke(led, s(2.5), s(4), 1.4, 0.55, 0.92)
    slideInTop(panel, UDim2.new(0.5, s(-250), 0.45, s(-210)), UDim2.new(0, s(500), 0, s(420)), 0.32, 0.03)

    local titleBar, btns = makeTitleBar(panel, T.APP_MAIN, {
        {id = "kill", text = "!", color = C.warning},
        {id = "min", text = "-", color = C.text},
        {id = "info", text = "?", color = C.accent}
    })
    setupDrag(panel, titleBar)

    local statusRow = Instance.new("Frame")
    statusRow.Size = UDim2.new(1, -s(12), 0, s(20))
    statusRow.Position = UDim2.new(0, s(6), 0, s(32))
    statusRow.BackgroundTransparency = 1
    statusRow.Parent = panel

    StatusLabel = Instance.new("TextLabel")
    StatusLabel.Size = UDim2.new(1, 0, 1, 0)
    StatusLabel.BackgroundTransparency = 1
    StatusLabel.Text = T.CONNECTING
    StatusLabel.TextColor3 = C.dim
    StatusLabel.Font = C.font
    StatusLabel.TextSize = s(10)
    StatusLabel.TextXAlignment = Enum.TextXAlignment.Left
    StatusLabel.Parent = statusRow

    local muteBtn = Instance.new("TextButton")
    muteBtn.Size = UDim2.new(0, s(70), 0, s(20))
    muteBtn.Position = UDim2.new(1, -s(140), 0, s(32))
    muteBtn.BackgroundColor3 = Color3.fromRGB(60, 20, 20)
    muteBtn.BorderSizePixel = 0
    muteBtn.Text = T.MUTE_LIST
    muteBtn.TextColor3 = C.danger
    muteBtn.Font = C.font
    muteBtn.TextSize = s(9)
    muteBtn.Parent = panel
    addCorners(muteBtn, s(3))
    addStroke(muteBtn, C.danger, s(0.5))
    track(muteBtn.MouseEnter:Connect(function() TweenService:Create(muteBtn, TweenInfo.new(0.14), {BackgroundTransparency = 0.15}):Play() end))
    track(muteBtn.MouseLeave:Connect(function() TweenService:Create(muteBtn, TweenInfo.new(0.14), {BackgroundTransparency = 0}):Play() end))
    track(muteBtn.MouseButton1Click:Connect(function() showMuteList() end))

    local settingsBtn = Instance.new("TextButton")
    settingsBtn.Size = UDim2.new(0, s(60), 0, s(20))
    settingsBtn.Position = UDim2.new(1, -s(64), 0, s(32))
    settingsBtn.BackgroundColor3 = Color3.fromRGB(20, 40, 20)
    settingsBtn.BorderSizePixel = 0
    settingsBtn.Text = T.SETTINGS
    settingsBtn.TextColor3 = C.accent
    settingsBtn.Font = C.font
    settingsBtn.TextSize = s(9)
    settingsBtn.Parent = panel
    addCorners(settingsBtn, s(3))
    addStroke(settingsBtn, C.accent, s(0.5))
    track(settingsBtn.MouseEnter:Connect(function() TweenService:Create(settingsBtn, TweenInfo.new(0.14), {BackgroundTransparency = 0.15}):Play() end))
    track(settingsBtn.MouseLeave:Connect(function() TweenService:Create(settingsBtn, TweenInfo.new(0.14), {BackgroundTransparency = 0}):Play() end))
    track(settingsBtn.MouseButton1Click:Connect(function()
        panelOut(panel, UDim2.new(0.5, s(-250), 0.45, s(-210)), UDim2.new(0, s(500), 0, s(420)), function()
            gui.Enabled = false
            buildStartup()
        end)
    end))

    local function makeChatTab(text, x, width, color)
        local btn = Instance.new("TextButton")
        btn.Size = UDim2.fromOffset(s(width), s(22))
        btn.Position = UDim2.fromOffset(s(x), s(55))
        btn.BackgroundColor3 = color
        btn.BorderSizePixel = 0
        btn.Text = text
        btn.TextColor3 = Color3.fromRGB(0, 0, 0)
        btn.Font = C.font
        btn.TextSize = s(9)
        addCorners(btn, s(4))
        addStroke(btn, color, s(1))
        btn.Parent = panel
        return btn
    end
    GlobalTabBtn = makeChatTab(T.GLOBAL_TAB, 6, 90, C.accent)
    PrivateTabBtn = makeChatTab(T.PRIVATE_TAB, 102, 100, C.purple)
    PrivateTargetBtn = makeChatTab(T.SELECT_PLAYER, 208, 200, C.dim)
    PrivateTargetBtn.Visible = false
    track(GlobalTabBtn.MouseButton1Click:Connect(function()
        CurrentTab = "global"
        PrivateTargetBtn.Visible = false
        GlobalTabBtn.BackgroundColor3 = C.accent
        PrivateTabBtn.BackgroundColor3 = C.dim
        renderMessages(GlobalMessages)
    end))
    track(PrivateTabBtn.MouseButton1Click:Connect(function()
        CurrentTab = "private"
        PrivateTargetBtn.Visible = true
        GlobalTabBtn.BackgroundColor3 = C.dim
        PrivateTabBtn.BackgroundColor3 = C.purple
        showPlayerPicker()
        renderPrivateMessages(PrivateMessages)
    end))
    track(PrivateTargetBtn.MouseButton1Click:Connect(showPlayerPicker))

    ChatScroll = Instance.new("ScrollingFrame")
    ChatScroll.Size = UDim2.new(1, -s(12), 1, -s(170))
    ChatScroll.Position = UDim2.new(0, s(6), 0, s(82))
    ChatScroll.BackgroundColor3 = C.bg
    ChatScroll.BackgroundTransparency = 0.2
    ChatScroll.BorderSizePixel = 0
    ChatScroll.ScrollBarThickness = s(4)
    ChatScroll.ScrollBarImageColor3 = C.accent
    ChatScroll.CanvasSize = UDim2.new(0, 0, 0, 0)
    ChatScroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
    ChatScroll.ClipsDescendants = true
    addCorners(ChatScroll, s(4))
    addStroke(ChatScroll, C.accentDark, s(0.5))
    ChatScroll.Parent = panel
    local scrollLayout = Instance.new("UIListLayout")
    scrollLayout.Padding = UDim.new(0, s(6))
    scrollLayout.Parent = ChatScroll
    track(scrollLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
        ChatScroll.CanvasSize = UDim2.new(0, 0, 0, scrollLayout.AbsoluteContentSize.Y + s(8))
    end))

    InputBox = Instance.new("TextBox")
    InputBox.Size = UDim2.new(1, -s(90), 0, s(34))
    InputBox.Position = UDim2.new(0, s(6), 1, -s(82))
    InputBox.BackgroundColor3 = C.bg
    InputBox.BackgroundTransparency = 0.2
    InputBox.BorderSizePixel = 0
    InputBox.Text = ""
    InputBox.PlaceholderText = T.INPUT_PH
    InputBox.TextColor3 = C.text
    InputBox.Font = C.font
    InputBox.TextSize = s(11)
    InputBox.TextXAlignment = Enum.TextXAlignment.Left
    InputBox.ClearTextOnFocus = false
    InputBox.ClipsDescendants = true
    addCorners(InputBox, s(4))
    addStroke(InputBox, C.accentDark, s(0.5))
    InputBox.Parent = panel
    track(InputBox:GetPropertyChangedSignal("Text"):Connect(function()
        if #InputBox.Text > MAX_LEN then InputBox.Text = string.sub(InputBox.Text, 1, MAX_LEN) end
    end))

    SendBtn = Instance.new("TextButton")
    SendBtn.Size = UDim2.new(0, s(80), 0, s(34))
    SendBtn.Position = UDim2.new(1, -s(86), 1, -s(82))
    SendBtn.BackgroundColor3 = C.accent
    SendBtn.BorderSizePixel = 0
    SendBtn.Text = T.SEND
    SendBtn.TextColor3 = Color3.fromRGB(0, 0, 0)
    SendBtn.Font = C.font
    SendBtn.TextSize = s(11)
    addCorners(SendBtn, s(4))
    addStroke(SendBtn, C.accent, s(1))
    SendBtn.Parent = panel

    local BanNotice = Instance.new("TextLabel")
    BanNotice.Size = UDim2.new(1, -s(12), 0, s(40))
    BanNotice.Position = UDim2.new(0, s(6), 1, -s(44))
    BanNotice.BackgroundTransparency = 1
    BanNotice.Text = ""
    BanNotice.TextColor3 = C.danger
    BanNotice.Font = C.font
    BanNotice.TextSize = s(10)
    BanNotice.TextWrapped = true
    BanNotice.TextXAlignment = Enum.TextXAlignment.Left
    BanNotice.TextYAlignment = Enum.TextYAlignment.Top
    BanNotice.Visible = false
    BanNotice.Parent = panel

    local BanUntil = 0
    local BanReason = ""
    local function updateBanState()
        local remaining = BanUntil - os.time() * 1000
        if remaining > 0 then
            InputBox.TextEditable = false
            SendBtn.Active = false
            SendBtn.AutoButtonColor = false
            SendBtn.BackgroundColor3 = C.dim
            SendBtn.TextColor3 = C.danger
            SendBtn.Text = isVN and "G̶Ử̶I̶" or "S̶E̶N̶D̶"
            BanNotice.Text = (isVN and "Bạn đã bị ban trong: " or "You are banned for: ") .. formatRemainingDuration(remaining) .. "\n" .. (isVN and "Với lý do: " or "Reason: ") .. (BanReason ~= "" and BanReason or (isVN and "Không nêu lý do" or "No reason provided"))
            BanNotice.Visible = true
        elseif BanUntil > 0 then
            BanUntil = 0
            BanReason = ""
            InputBox.TextEditable = true
            SendBtn.Active = true
            SendBtn.AutoButtonColor = true
            SendBtn.BackgroundColor3 = C.accent
            SendBtn.TextColor3 = Color3.fromRGB(0, 0, 0)
            SendBtn.Text = T.SEND
            BanNotice.Visible = false
            if StatusLabel and StatusLabel.Parent then
                StatusLabel.Text = T.ONLINE
                StatusLabel.TextColor3 = C.accent
            end
        end
    end
    local function setBanState(expires, reason)
        BanUntil = tonumber(expires) or 0
        BanReason = tostring(reason or "")
        updateBanState()
    end

    local function getCooldown() return math.max(0, COOLDOWN - (os.clock() - LastSendTime)) end

    local function trySend()
        if BanUntil > os.time() * 1000 then updateBanState() return end
        if getCooldown() > 0.5 then return end
        local text = InputBox.Text
        if text == "" or #text > MAX_LEN then return end
        if CurrentTab == "private" and not PrivateTarget then showPlayerPicker() return end
        InputBox.Text = ""
        LastSendTime = os.clock()
        StatusLabel.Text = T.SENDING
        StatusLabel.TextColor3 = C.warning
        task.spawn(function()
            local ok, data = CurrentTab == "private" and sendPrivateMessage(text) or sendMessage(text)
            if ok and data and data.success then
                StatusLabel.Text = T.SENT
                StatusLabel.TextColor3 = C.accent
                task.delay(1, function()
                    if IsConnected and StatusLabel and StatusLabel.Parent then
                        StatusLabel.Text = T.ONLINE
                        StatusLabel.TextColor3 = C.accent
                    end
                end)
                task.wait(0.15)
                if CurrentTab == "private" then
                    local privateData = fetchPrivateMessages()
                    renderPrivateMessages(privateData)
                else
                    local fetchOk, fetchData = fetchMessages()
                    if fetchOk and fetchData and fetchData.messages then
                        local last = fetchData.messages[#fetchData.messages]
                        if last then LastMessageId = last.id end
                        renderMessages(fetchData.messages)
                        if ChatScroll then ChatScroll.CanvasPosition = Vector2.new(0, ChatScroll.AbsoluteCanvasSize.Y) end
                    end
                end
            else
                if type(data) == "table" and data.error == "Banned" and data.expires then
                    setBanState(data.expires, data.reason)
                    StatusLabel.Text = T.BANNED .. formatRemainingDuration(data.expires - os.time() * 1000)
                else
                    StatusLabel.Text = T.SEND_FAILED .. ": " .. tostring(type(data) == "table" and data.error or data or "?")
                end
                StatusLabel.TextColor3 = C.danger
            end
        end)
    end

    track(SendBtn.MouseEnter:Connect(function()
        if getCooldown() < 0.5 then TweenService:Create(SendBtn, TweenInfo.new(0.14), {BackgroundTransparency = 0.15}):Play() end
    end))
    track(SendBtn.MouseLeave:Connect(function() TweenService:Create(SendBtn, TweenInfo.new(0.14), {BackgroundTransparency = 0}):Play() end))
    track(SendBtn.MouseButton1Click:Connect(trySend))
    track(InputBox.FocusLost:Connect(function(enter) if enter then trySend() end end))

    task.spawn(function()
        while PollingActive and MainGui and SendBtn and SendBtn.Parent do
            updateBanState()
            local cd = getCooldown()
            if cd > 0.5 then
                SendBtn.Text = string.format("[%ds]", math.ceil(cd))
                SendBtn.BackgroundColor3 = Color3.fromRGB(80, 80, 80)
            else
                SendBtn.Text = T.SEND
                SendBtn.BackgroundColor3 = C.accent
            end
            task.wait(0.5)
        end
    end)

    track(btns.info.MouseButton1Click:Connect(function()
        if gui:FindFirstChild("InfoPanel") then return end
        local infoPanel = Instance.new("Frame")
        infoPanel.Name = "InfoPanel"
        infoPanel.Size = UDim2.new(0, s(360), 0, s(260))
        infoPanel.Position = UDim2.new(0.5, s(-180), 0.5, s(-130))
        infoPanel.BackgroundColor3 = C.glass
        infoPanel.BackgroundTransparency = 0.03
        infoPanel.BorderSizePixel = 0
        infoPanel.ZIndex = 100
        infoPanel.Parent = gui
        addCorners(infoPanel, s(8))
        addStroke(infoPanel, C.accent, s(1))
        slideInTop(infoPanel, UDim2.new(0.5, s(-180), 0.5, s(-130)), UDim2.new(0, s(360), 0, s(260)), 0.3, 0.03)

        local infoBar = Instance.new("Frame")
        infoBar.Size = UDim2.new(1, 0, 0, s(28))
        infoBar.BackgroundTransparency = 1
        infoBar.Active = true
        infoBar.ZIndex = 101
        infoBar.Parent = infoPanel
        setupDrag(infoPanel, infoBar)

        local infoLbl = Instance.new("TextLabel")
        infoLbl.Size = UDim2.new(1, -s(40), 1, 0)
        infoLbl.Position = UDim2.new(0, s(10), 0, 0)
        infoLbl.BackgroundTransparency = 1
        infoLbl.Text = T.GUIDE_TITLE
        infoLbl.TextColor3 = C.accent
        infoLbl.Font = C.font
        infoLbl.TextSize = s(12)
        infoLbl.TextXAlignment = Enum.TextXAlignment.Left
        infoLbl.ZIndex = 101
        infoLbl.Parent = infoBar

        local infoClose = Instance.new("TextButton")
        infoClose.Size = UDim2.new(0, s(24), 0, s(22))
        infoClose.Position = UDim2.new(1, -s(28), 0, s(3))
        infoClose.BackgroundColor3 = Color3.fromRGB(20, 40, 20)
        infoClose.BorderSizePixel = 0
        infoClose.Text = T.OK
        infoClose.TextColor3 = C.accent
        infoClose.Font = C.font
        infoClose.TextSize = s(10)
        infoClose.ZIndex = 101
        addCorners(infoClose, s(4))
        addStroke(infoClose, C.accent, s(0.5))
        infoClose.Parent = infoBar
        track(infoClose.MouseButton1Click:Connect(function()
            panelOut(infoPanel, UDim2.new(0.5, s(-180), 0.5, s(-130)), UDim2.new(0, s(360), 0, s(260)), function() infoPanel:Destroy() end)
        end))

        local infoScroll = Instance.new("ScrollingFrame")
        infoScroll.Size = UDim2.new(1, -s(10), 1, -s(35))
        infoScroll.Position = UDim2.new(0, s(5), 0, s(30))
        infoScroll.BackgroundTransparency = 1
        infoScroll.ScrollBarThickness = s(3)
        infoScroll.ScrollBarImageColor3 = C.accent
        infoScroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
        infoScroll.ZIndex = 101
        infoScroll.Parent = infoPanel

        local txt = Instance.new("TextLabel")
        txt.Size = UDim2.new(1, -s(10), 0, 0)
        txt.Position = UDim2.new(0, s(5), 0, 0)
        txt.BackgroundTransparency = 1
        txt.TextXAlignment = Enum.TextXAlignment.Left
        txt.TextYAlignment = Enum.TextYAlignment.Top
        txt.TextWrapped = true
        txt.AutomaticSize = Enum.AutomaticSize.Y
        txt.Font = C.font
        txt.TextSize = s(11)
        txt.TextColor3 = C.text
        txt.ZIndex = 101
        txt.Text = T.GUIDE_TEXT
        txt.Parent = infoScroll
    end))

    local killConfirm = false
    track(btns.kill.MouseButton1Click:Connect(function()
        if killConfirm then
            killConfirm = false
            btns.kill.Text = "!"
            btns.kill.TextColor3 = C.warning
            local st = btns.kill:FindFirstChildOfClass("UIStroke")
            if st then st.Color = C.warning end
            glitch(panel, function() cleanup() end)
        else
            killConfirm = true
            btns.kill.Text = "X"
            btns.kill.TextColor3 = C.danger
            local st = btns.kill:FindFirstChildOfClass("UIStroke")
            if st then st.Color = C.danger end
            task.delay(3, function()
                if killConfirm and btns.kill and btns.kill.Parent then
                    killConfirm = false
                    btns.kill.Text = "!"
                    btns.kill.TextColor3 = C.warning
                    local st2 = btns.kill:FindFirstChildOfClass("UIStroke")
                    if st2 then st2.Color = C.warning end
                end
            end)
        end
    end))

    track(btns.min.MouseButton1Click:Connect(function()
        panelOut(panel, UDim2.new(0.5, s(-250), 0.45, s(-210)), UDim2.new(0, s(500), 0, s(420)), function()
            panel.Visible = false
            if not gui:FindFirstChild("Mini") then
                local mini = Instance.new("Frame")
                mini.Name = "Mini"
                mini.Size = UDim2.new(0, s(90), 0, s(36))
                if MiniPos and MiniPos[1] and MiniPos[2] then
                    mini.Position = UDim2.fromOffset(MiniPos[1], MiniPos[2])
                else
                    mini.Position = UDim2.new(0.05, 0, 0.2, 0)
                end
                mini.BackgroundColor3 = C.glass
                mini.BackgroundTransparency = 0.1
                mini.BorderSizePixel = 0
                addCorners(mini, s(6))
                addStroke(mini, C.accent, s(1.5))
                mini.Parent = gui
                setupDrag(mini, mini, function(x, y)
                    MiniPos = {x, y}
                    saveSettings()
                end)
                local logoAsset = ensureLogo()
                if logoAsset then
                    local lc = Instance.new("Frame")
                    lc.Size = UDim2.fromOffset(s(22), s(22))
                    lc.Position = UDim2.new(0, s(6), 0.5, -s(11))
                    lc.BackgroundTransparency = 1
                    lc.ClipsDescendants = true
                    lc.Parent = mini
                    local img = Instance.new("ImageLabel")
                    img.Size = UDim2.new(1, 0, 1, 0)
                    img.BackgroundTransparency = 1
                    img.Image = logoAsset
                    img.ScaleType = Enum.ScaleType.Fit
                    img.ZIndex = 2
                    img.Parent = lc
                    enchantedGlint(lc)
                end
                local openBtn = Instance.new("TextButton")
                openBtn.Size = UDim2.new(0, s(50), 0, s(28))
                openBtn.Position = UDim2.new(1, -s(54), 0.5, -s(14))
                openBtn.BackgroundColor3 = C.accent
                openBtn.BorderSizePixel = 0
                openBtn.Text = "+"
                openBtn.TextColor3 = Color3.fromRGB(0, 0, 0)
                openBtn.Font = C.font
                openBtn.TextSize = s(14)
                addCorners(openBtn, s(4))
                addStroke(openBtn, C.accent, s(1))
                openBtn.Parent = mini
                track(openBtn.MouseButton1Click:Connect(function()
                    mini:Destroy()
                    slideInTop(panel, UDim2.new(0.5, s(-250), 0.45, s(-210)), UDim2.new(0, s(500), 0, s(420)), 0.3, 0.03)
                end))
            end
        end)
    end))

    task.spawn(function()
        task.wait(0.3)
        local ok, data = fetchMessages()
        if ok and data and data.messages then
            IsConnected = true
            StatusLabel.Text = T.ONLINE
            StatusLabel.TextColor3 = C.accent
            local last = data.messages[#data.messages]
            if last then LastMessageId = last.id end
            renderMessages(data.messages)
            if ChatScroll then ChatScroll.CanvasPosition = Vector2.new(0, ChatScroll.AbsoluteCanvasSize.Y) end
            for _, m in ipairs(data.messages) do updateCache(m) end
        else
            StatusLabel.Text = T.CONN_FAILED
            StatusLabel.TextColor3 = C.danger
            renderMessages({})
        end
    end)

    task.spawn(function()
        while PollingActive and MainGui and MainGui.Parent do
            task.wait(POLL_INTERVAL)
            if not PollingActive then break end
            local ok, data = fetchMessages()
            if ok and data and data.messages then
                IsConnected = true
                GlobalMessages = data.messages
                local newLast = data.messages[#data.messages]
                local hasNew = newLast and newLast.id ~= LastMessageId
                for _, m in ipairs(data.messages) do updateCache(m) end
                if hasNew then
                    LastMessageId = newLast.id
                    if CurrentTab == "global" then renderMessages(data.messages) end
                    if ChatScroll and CurrentTab == "global" then ChatScroll.CanvasPosition = Vector2.new(0, ChatScroll.AbsoluteCanvasSize.Y) end
                    for _, m in ipairs(data.messages) do
                        if not SeenIds[m.id] then
                            SeenIds[m.id] = true
                            if tostring(m.placeId or "") == tostring(game.PlaceId) and m.jobId == tostring(game.JobId) and m.username ~= "Anonymous" then
                                createOverheadBubble(m.userId, m.text or "")
                            end
                        end
                    end
                end
                if CurrentTab == "private" and PrivateTarget then
                    renderPrivateMessages(fetchPrivateMessages())
                end
                if StatusLabel and StatusLabel.Parent then
                    StatusLabel.Text = T.ONLINE
                    StatusLabel.TextColor3 = C.accent
                end
            else
                IsConnected = false
                if StatusLabel and StatusLabel.Parent then
                    StatusLabel.Text = T.OFFLINE
                    StatusLabel.TextColor3 = C.danger
                end
            end
        end
    end)
end

function cleanup()
    if CleanedUp then return end
    CleanedUp = true
    PollingActive = false
    for _, conn in ipairs(Connections) do pcall(function() conn:Disconnect() end) end
    table.clear(Connections)
    for _, bb in pairs(BillboardGuis) do pcall(function() bb:Destroy() end) end
    table.clear(BillboardGuis)
    for _, g in pairs(CoreGui:GetChildren()) do
        if g.Name == "MamboGlobalChat" or g.Name == "MamboGlobalChat_Setup" then g:Destroy() end
        local prof = g:FindFirstChild("MamboProfilePopup")
        if prof then prof:Destroy() end
        local mute = g:FindFirstChild("MamboMuteList")
        if mute then mute:Destroy() end
    end
    MainGui = nil
    StartupGui = nil
end

buildStartup()